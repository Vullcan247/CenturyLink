package com.example.demo.controller;



import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CC1 {

    
    private RestTemplate restTemplate;

    
    public CC1() {
       
        restTemplate = new RestTemplate();
        
        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor("Vullcan247", "1Theresa"));
    }

    @GetMapping
    public GithubUser[] getGitHubData(@RequestParam String name) {
       
        final String uri = "https://api.github.com/users/";

        // name -> followers of name
        // followers of followers of name
        // followers of followers of followers of name
        // name can return 5 results, next tier can be 25 results
        // max output of 125 followers
        // max api calls: 31, 1 initial, 5 second stage, 25 third stage
        
        // first call is different, manually add followers to the url
        GithubUser[] firstFollowers = getFirstFiveFollowers(uri + name + "/followers");
       
        for (GithubUser f : firstFollowers) {
            
            f.setFollowers(getFirstFiveFollowers(f.getFollowers_url()));
            
            if (f.getFollowers() != null) {
               
                for (GithubUser s : f.getFollowers()) {
                    
                    s.setFollowers(getFirstFiveFollowers(s.getFollowers_url()));
                }
            }
        }
        return firstFollowers;
    }

    private GithubUser[] getFirstFiveFollowers(String url) {
       
    	
        GithubUser[] result = restTemplate.getForObject(url + "?per_page=5", GithubUser[].class);
        // if the result is null (no results) or 0 then return nothing
        if (result == null || result.length == 0) {
            return null;
        }

        return result;
    }
}











//import org.springframework.http.client.support.BasicAuthorizationInterceptor;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
//
//@RestController
//public class CC1 {
//
//    @GetMapping
//    public GithubUser[] getGitHubData(@RequestParam String name) {
//        final String uri = "https://api.github.com/users/";
//        RestTemplate restTemplate = new RestTemplate();
//        restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor("Vullcan247", "1Theresa"));
//        GithubUser[] result = restTemplate.getForObject(uri+name+"/followers",GithubUser[].class);
//       
//        GithubUser[] trimResult = new GithubUser[2];
//        System.arraycopy (result, 0, trimResult, 0, 1);
//        		
//        
//        for(GithubUser u: result) {
//        	GithubUser[] followers = restTemplate.getForObject(u.getFollowers_url(),GithubUser[].class);
//        	u.setFollowers(followers);
//        	
//        	GithubUser[] trimfollowers = new GithubUser[1];
//        	System.arraycopy(followers, 0, trimfollowers, 0, 1);
//        
//        
//        for(GithubUser n: followers) {
//        	GithubUser[] nfollowers = restTemplate.getForObject(n.getFollowers_url(),GithubUser[].class);
//        	n.setFollowers(nfollowers);
//        	
//        	GithubUser[] trimNfollowers = new GithubUser[1];
//        	System.arraycopy(nfollowers, 0, trimNfollowers, 0, 1);
//       
//    
//            for (GithubUser j : nfollowers) {
//                GithubUser[] jfollowers = restTemplate.getForObject(j.getFollowers_url(), GithubUser[].class);
//                j.setFollowers(jfollowers);
//                
//                GithubUser[] trimJfollowers = new GithubUser[1];
//                System.arraycopy(jfollowers, 0, trimJfollowers, 0, 1);
//            }
//    
//            }
//        }
//  
//
//        
//		return result;
//    }
//    
//}
//
//
////for (GithubUser u : result) {
////    GithubUser[] followers = restTemplate.getForObject(u.getFollowers_url(), GithubUser[].class);
////    u.setFollowers(followers);
////    for (GithubUser j : result) {
////        GithubUser[] jfollowers = restTemplate.getForObject(j.getFollowers_url(), GithubUser[].class);
////        j.setFollowers(jfollowers);
////        
////
////    }
////
////}